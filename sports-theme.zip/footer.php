<footer class="bg-blue border-top-red">
    <div class="row pt-2 w-100">
        <div class="col-md-6">
            <div class="row w-100">
                <a href="" class="text-light mr-3 txt-bold txt-md">Home</a>
                <a href="" class="text-light mr-3 txt-bold txt-md">News</a>
                <a href="" class="text-light mr-3 txt-bold txt-md">About Us</a>
                <a href="" class="text-light mr-3 txt-bold txt-md">Contact</a>
            </div>
        </div>
        <div class="col-md-6">
            <p class="text-light" style="float: right;"> Kwik12 © 2021. All Rights Reserved.</p>
        </div>
    </div>
</footer>
<?php wp_footer();?>
</body>
</html>